package com.example.experiment1

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.Toast



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textView:TextView
        textView=findViewById(R.id.tvtextView)
        val btnView:Button
        val btnFont:Button
        btnFont=findViewById(R.id.btFont)
        var fontcolor:Int=0
        var fontsize:Float=5f
        btnView=findViewById<Button>(R.id.btcolor)
        btnView.setOnClickListener {
            when (fontcolor) {
                0 -> textView.setTextColor(Color.RED)
                1 -> textView.setTextColor(Color.GREEN)
                2 -> textView.setTextColor(Color.BLUE)
            }
            fontcolor++
            Toast.makeText(applicationContext,"Colour Changed",Toast.LENGTH_SHORT).show()
        }
        btnFont.setOnClickListener{
            textView.setTextSize(fontsize)
            fontsize=(fontsize+5)%50
            Toast.makeText(applicationContext,"Font Size Changed",Toast.LENGTH_SHORT).show()
        }

    }
}