package com.example.assignment1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var tvno:TextView=findViewById(R.id.tvcountd)
        var count=0
        var countadd: Button =findViewById(R.id.btcountin)
        var countsub: Button =findViewById(R.id.btcountde)
        countadd.setOnClickListener{
            count=count+1
            tvno.text=count.toString()
        }
        countsub.setOnClickListener{
            count=count-1
            tvno.text=count.toString()
        }
    }
}